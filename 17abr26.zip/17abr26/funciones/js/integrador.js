function ejemploIntegrador() {
    const salida = document.getElementById("outputIntegrador");
    salida.innerText = "Obteniendo usuarios... ⏳";
  
    // Función flecha que devuelve una promesa con fetch
    const obtenerUsuarios = () => {
      return fetch("https://jsonplaceholder.typicode.com/users")
        .then(respuesta => respuesta.json());
    };
  
    // Consumir la promesa
    obtenerUsuarios()
      .then(usuarios => {
        let texto = "Usuarios obtenidos:\n\n";
        usuarios.forEach(u => {
          texto += `👤 ${u.name} (${u.email})\n`;
        });
        salida.innerText = texto;
      })
      .catch(error => {
        salida.innerText = "Error al obtener usuarios: " + error;
      });
  }
  