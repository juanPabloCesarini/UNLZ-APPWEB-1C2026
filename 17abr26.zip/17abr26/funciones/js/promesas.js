function ejemploPromesa() {
    let salida = "";
  
    // Promesa básica
    const miPromesa = new Promise((resolve, reject) => {
      let exito = true;// Cambiá a false para ver el error
      if (exito) {
        resolve("La operación fue exitosa ✅");
      } else {
        reject("Ocurrió un error ❌");
      }
    });
  
    miPromesa
      .then(resultado => {
        salida += resultado + "\n";
        // Promesa con setTimeout
        return new Promise(resolve => {
          setTimeout(() => resolve("Esperaste 2 segundos ⏳"), 2000);
        });
      })
      .then(mensaje => {
        salida += mensaje + "\n";
        document.getElementById("outputPromesa").innerText = salida;
      })
      .catch(error => {
        salida += error;
        document.getElementById("outputPromesa").innerText = salida;
      });
  }
  