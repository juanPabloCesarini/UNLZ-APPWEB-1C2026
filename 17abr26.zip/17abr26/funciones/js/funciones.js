function ejemploFlecha() {
    let salida = "";
  
    // Función tradicional
    function saludar(nombre) {
      return "Hola " + nombre;
    }
  
    // Función flecha
    const saludarFlecha = (nombre) => "Hola " + nombre;
  
    salida += "Función tradicional: " + saludar("Juan") + "\n";
    salida += "Función flecha: " + saludarFlecha("Pablo") + "\n";
  
    // Flecha sin parámetros
    const hola = () => "¡Hola mundo!";
    salida += "Flecha sin parámetros: " + hola() + "\n";
  
    // Flecha con varias instrucciones
    const sumar = (a, b) => {
      let resultado = a + b;
      return resultado;
    };
    salida += "Suma (5 + 3): " + sumar(5, 3);
  
    document.getElementById("outputFlecha").innerText = salida;
  }
  