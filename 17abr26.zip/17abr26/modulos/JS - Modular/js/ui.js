// ui.js
// Este módulo se encarga de manipular el DOM (interfaz)

export const container = document.getElementById("pokemonContainer");
export const spinner = document.getElementById("spinner");

export const showSpinner = () => spinner.classList.remove("d-none");
export const hideSpinner = () => spinner.classList.add("d-none");

export const renderPokemon = (pokemon) => {
  const { name, sprites, types } = pokemon;
  const typeList = types.map((t) => `<span class="badge bg-secondary me-1">${t.type.name}</span>`).join("");
  return `
    <div class="card shadow">
      <img src="${sprites.front_default}" class="card-img-top" alt="${name}">
      <div class="card-body text-center">
        <h5 class="card-title text-capitalize">${name}</h5>
        <p>${typeList}</p>
      </div>
    </div>`;
};

export const showError = (message) => {
  Swal.fire("Error", message, "error");
};