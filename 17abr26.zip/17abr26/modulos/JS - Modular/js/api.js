// api.js
// Este módulo se encarga exclusivamente de las peticiones a la API

const API_URL = "https://pokeapi.co/api/v2/pokemon";

export const fetchPokemonList = async (limit = 20) => {
  const res = await fetch(`${API_URL}?limit=${limit}`);
  if (!res.ok) throw new Error("Error al obtener la lista de Pokémon");
  return res.json();
};

export const fetchPokemonByName = async (name) => {
  const res = await fetch(`${API_URL}/${name.toLowerCase()}`);
  if (!res.ok) throw new Error("Pokémon no encontrado");
  return res.json();
};