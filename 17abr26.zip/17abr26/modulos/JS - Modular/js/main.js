// main.js
// Módulo principal: conecta la lógica de API y la interfaz (UI)

import { fetchPokemonList, fetchPokemonByName } from "./api.js";
import { container, showSpinner, hideSpinner, renderPokemon, showError } from "./ui.js";

const searchBtn = document.getElementById("searchBtn");
const input = document.getElementById("pokemonInput");

export const loadAllPokemons = async () => {
  try {
    showSpinner();
    container.innerHTML = "";
    container.classList.remove("justify-content-center");

    const data = await fetchPokemonList(20);
    const details = await Promise.all(
      data.results.map(async (p) => {
        const res = await fetch(p.url);
        return res.json();
      })
    );

    container.innerHTML = details.map((p) => `<div class="col-md-3">${renderPokemon(p)}</div>`).join("");
  } catch (error) {
    showError("No se pudieron cargar los Pokémon.");
  } finally {
    hideSpinner();
  }
};

export const searchPokemon = async () => {
  const query = input.value.trim().toLowerCase();
  if (!query) {
    Swal.fire("Atención", "Debes escribir un nombre antes de buscar.", "warning");
    return;
  }
  try {
    showSpinner();
    container.innerHTML = "";
    container.classList.add("justify-content-center");

    const pokemon = await fetchPokemonByName(query);
    container.innerHTML = `<div class="col-md-4 single-card">${renderPokemon(pokemon)}</div>`;
  } catch (error) {
    showError(`El Pokémon "${query}" no existe.`);
  } finally {
    hideSpinner();
  }
};

document.addEventListener("DOMContentLoaded", loadAllPokemons);
searchBtn.addEventListener("click", searchPokemon);